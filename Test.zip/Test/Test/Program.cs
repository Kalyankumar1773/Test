﻿// See https://aka.ms/new-console-template for more information
using Test;

Console.WriteLine("Hello, World!");

Test.Class1 dat = new Class1();
dat.Main();